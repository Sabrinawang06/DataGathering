# Mouse-Experiment-Random-Assignment-
Simulate an experiment to randomly assign 20 mice into experimental group and control group.
"A line I wrote on my local computer"
