# Weighting-Adjustment-in-Survey
Adjust weight using slider to understand the effect of weighting in survey analysis 
