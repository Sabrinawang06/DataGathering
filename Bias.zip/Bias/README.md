# Bias-vs-Variance
Use target shooting and density diagram to better understand bias and variance  
