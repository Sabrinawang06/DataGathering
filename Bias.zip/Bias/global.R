index = sample(1:4,1)

question = c('Try to create a model for large bias and low reliability.',
             'Try to create a model for large bias and high reliability.',
             'Try to create a model for no bias and low reliability.',
             'Try to create a model for no bias and high reliability.')
